import os
import numpy as np
import pandas as pd

import torch
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from utils.timefeatures import time_features
import warnings

warnings.filterwarnings('ignore')


class Dataset_ETT_hour(Dataset):
    def __init__(self, root_path, flag='train', size=None,
                 features='S', data_path='ETTh1.csv',
                 target='OT', scale=True, timeenc=0, freq='h', cycle=None):
        # size [seq_len, label_len, pred_len]
        # info
        if size == None:
            self.seq_len = 24 * 4 * 4
            self.label_len = 24 * 4
            self.pred_len = 24 * 4
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['train', 'test', 'val']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.cycle = cycle

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path,
                                          self.data_path))

        border1s = [0, 12 * 30 * 24 - self.seq_len, 12 * 30 * 24 + 4 * 30 * 24 - self.seq_len]
        border2s = [12 * 30 * 24, 12 * 30 * 24 + 4 * 30 * 24, 12 * 30 * 24 + 8 * 30 * 24]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns[1:]
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]

        if self.scale:
            train_data = df_data[border1s[0]:border2s[0]]
            self.scaler.fit(train_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        df_stamp = df_raw[['date']][border1:border2]
        df_stamp['date'] = pd.to_datetime(df_stamp.date)
        if self.timeenc == 0:
            df_stamp['month'] = df_stamp.date.apply(lambda row: row.month, 1)
            df_stamp['day'] = df_stamp.date.apply(lambda row: row.day, 1)
            df_stamp['weekday'] = df_stamp.date.apply(lambda row: row.weekday(), 1)
            df_stamp['hour'] = df_stamp.date.apply(lambda row: row.hour, 1)
            data_stamp = df_stamp.drop(['date'], 1).values
        elif self.timeenc == 1:
            data_stamp = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = data_stamp.transpose(1, 0)

        self.data_x = data[border1:border2]
        self.data_y = data[border1:border2]
        self.data_stamp = data_stamp

        # add cycle
        self.cycle_index = (np.arange(len(data)) % self.cycle)[border1:border2]

    def __getitem__(self, index):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin:s_end]
        seq_y = self.data_y[r_begin:r_end]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        cycle_index = torch.tensor(self.cycle_index[s_end])


        return seq_x, seq_y, seq_x_mark, seq_y_mark, cycle_index

    def __len__(self):
        return len(self.data_x) - self.seq_len - self.pred_len + 1

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)


class Dataset_ETT_minute(Dataset):
    def __init__(self, root_path, flag='train', size=None,
                 features='S', data_path='ETTm1.csv',
                 target='OT', scale=True, timeenc=0, freq='t', cycle=None):
        # size [seq_len, label_len, pred_len]
        # info
        if size == None:
            self.seq_len = 24 * 4 * 4
            self.label_len = 24 * 4
            self.pred_len = 24 * 4
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['train', 'test', 'val']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.cycle = cycle

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path,
                                          self.data_path))

        border1s = [0, 12 * 30 * 24 * 4 - self.seq_len, 12 * 30 * 24 * 4 + 4 * 30 * 24 * 4 - self.seq_len]
        border2s = [12 * 30 * 24 * 4, 12 * 30 * 24 * 4 + 4 * 30 * 24 * 4, 12 * 30 * 24 * 4 + 8 * 30 * 24 * 4]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns[1:]
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]

        if self.scale:
            train_data = df_data[border1s[0]:border2s[0]]
            self.scaler.fit(train_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        df_stamp = df_raw[['date']][border1:border2]
        df_stamp['date'] = pd.to_datetime(df_stamp.date)
        if self.timeenc == 0:
            df_stamp['month'] = df_stamp.date.apply(lambda row: row.month, 1)
            df_stamp['day'] = df_stamp.date.apply(lambda row: row.day, 1)
            df_stamp['weekday'] = df_stamp.date.apply(lambda row: row.weekday(), 1)
            df_stamp['hour'] = df_stamp.date.apply(lambda row: row.hour, 1)
            df_stamp['minute'] = df_stamp.date.apply(lambda row: row.minute, 1)
            df_stamp['minute'] = df_stamp.minute.map(lambda x: x // 15)
            data_stamp = df_stamp.drop(['date'], 1).values
        elif self.timeenc == 1:
            data_stamp = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = data_stamp.transpose(1, 0)

        self.data_x = data[border1:border2]
        self.data_y = data[border1:border2]
        self.data_stamp = data_stamp

        # add cycle
        self.cycle_index = (np.arange(len(data)) % self.cycle)[border1:border2]

    def __getitem__(self, index):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin:s_end]
        seq_y = self.data_y[r_begin:r_end]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        cycle_index = torch.tensor(self.cycle_index[s_end])

        return seq_x, seq_y, seq_x_mark, seq_y_mark, cycle_index

    def __len__(self):
        return len(self.data_x) - self.seq_len - self.pred_len + 1

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)


class Dataset_Custom(Dataset):
    def __init__(self, root_path, flag='train', size=None,
                 features='S', data_path='ETTh1.csv',
                 target='OT', scale=True, timeenc=0, freq='h', cycle=None):
        # size [seq_len, label_len, pred_len]
        # info
        if size == None:
            self.seq_len = 24 * 4 * 4
            self.label_len = 24 * 4
            self.pred_len = 24 * 4
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['train', 'test', 'val']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.cycle = cycle

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path,
                                          self.data_path))

        '''
        df_raw.columns: ['date', ...(other features), target feature]
        '''
        cols = list(df_raw.columns)
        cols.remove(self.target)
        cols.remove('date')
        df_raw = df_raw[['date'] + cols + [self.target]]

        # print(cols)
        num_train = int(len(df_raw) * 0.7)
        num_test = int(len(df_raw) * 0.2)
        num_vali = len(df_raw) - num_train - num_test
        border1s = [0, num_train - self.seq_len, len(df_raw) - num_test - self.seq_len]
        border2s = [num_train, num_train + num_vali, len(df_raw)]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns[1:]
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]

        if self.scale:
            train_data = df_data[border1s[0]:border2s[0]]
            self.scaler.fit(train_data.values)
            # print(self.scaler.mean_)
            # exit()
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        df_stamp = df_raw[['date']][border1:border2]
        df_stamp['date'] = pd.to_datetime(df_stamp.date)
        if self.timeenc == 0:
            df_stamp['month'] = df_stamp.date.apply(lambda row: row.month, 1)
            df_stamp['day'] = df_stamp.date.apply(lambda row: row.day, 1)
            df_stamp['weekday'] = df_stamp.date.apply(lambda row: row.weekday(), 1)
            df_stamp['hour'] = df_stamp.date.apply(lambda row: row.hour, 1)
            data_stamp = df_stamp.drop(['date'], 1).values
        elif self.timeenc == 1:
            data_stamp = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = data_stamp.transpose(1, 0)

        self.data_x = data[border1:border2]
        self.data_y = data[border1:border2]
        self.data_stamp = data_stamp

        # add cycle
        self.cycle_index = (np.arange(len(data)) % self.cycle)[border1:border2]

    def __getitem__(self, index):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin:s_end]
        seq_y = self.data_y[r_begin:r_end]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        cycle_index = torch.tensor(self.cycle_index[s_end])

        return seq_x, seq_y, seq_x_mark, seq_y_mark, cycle_index

    def __len__(self):
        return len(self.data_x) - self.seq_len - self.pred_len + 1

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)


class Dataset_CL(Dataset):
    def __init__(self, root_path, flag='train', size=None,
                 features='MS', data_path='CL_denoised.csv',
                 target='CL', scale=True, timeenc=0, freq='h', cycle=None):
        # size [seq_len, label_len, pred_len]
        # info
        if size == None:
            self.seq_len = 5
            self.label_len = 5
            self.pred_len = 1
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['train', 'test']  # 移除了'val'
        type_map = {'train': 0, 'test': 1}  # 移除了'val'
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.cycle = cycle

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

        # 记录特征数
        if self.features == 'S':
            self.n_features = 1
        else:
            # 从scaler中获取特征数
            if hasattr(self.scaler, 'mean_'):
                self.n_features = len(self.scaler.mean_)
            else:
                # 从data中推断
                if hasattr(self, 'data_x'):
                    self.n_features = self.data_x.shape[1]
                else:
                    self.n_features = None

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path, self.data_path))

        '''
        假设数据没有时间列，只包含特征列
        df_raw.columns: [feature1, feature2, ..., target feature]
        '''
        # 检查是否包含目标列
        if self.target not in df_raw.columns:
            raise ValueError(f"Target column '{self.target}' not found in data")

        cols = list(df_raw.columns)
        cols.remove(self.target)
        # 将目标列放在最后
        df_raw = df_raw[cols + [self.target]]

        # 训练集和测试集7:3比例
        num_train = int(len(df_raw) * 0.7)
        num_test = len(df_raw) - num_train

        # 边界设置：只有训练集和测试集
        border1s = [0, num_train - self.seq_len]
        border2s = [num_train, len(df_raw)]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns  # 所有列都是数据列
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]

        if self.scale:
            train_data = df_data[border1s[0]:border2s[0]]
            self.scaler.fit(train_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        # 创建全0的时间戳，长度与数据匹配
        data_len = border2 - border1
        if self.timeenc == 0:
            # 创建全0的时间特征（month, day, weekday, hour）
            data_stamp = np.zeros((data_len, 4))
        elif self.timeenc == 1:
            # 创建全0的时间编码（具体维度取决于time_features函数）
            # 这里假设time_features返回6个特征（根据常见实现）
            data_stamp = np.zeros((data_len, 6))
        else:
            # 如果不使用时间编码，创建空的数组
            data_stamp = np.zeros((data_len, 0))

        self.data_x = data[border1:border2]
        self.data_y = data[border1:border2]
        self.data_stamp = data_stamp

        # add cycle
        if self.cycle is not None:
            self.cycle_index = (np.arange(len(data)) % self.cycle)[border1:border2]
        else:
            self.cycle_index = np.zeros(len(self.data_x))

    def __getitem__(self, index):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin:s_end]
        seq_y = self.data_y[r_begin:r_end]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        cycle_index = torch.tensor(self.cycle_index[s_end])

        return seq_x, seq_y, seq_x_mark, seq_y_mark, cycle_index

    def __len__(self):
        return len(self.data_x) - self.seq_len - self.pred_len + 1

    def inverse_transform(self, data):
        """反标准化数据

        Args:
            data: 要反标准化的数据，形状应为 (n_samples, n_features)

        Returns:
            反标准化后的数据
        """
        if not self.scale:
            return data

        # 确保数据是numpy数组
        data_np = np.array(data)

        # 获取原始特征数
        if hasattr(self, 'n_features') and self.n_features is not None:
            n_features = self.n_features
        elif hasattr(self.scaler, 'mean_'):
            n_features = len(self.scaler.mean_)
        else:
            # 默认假设单变量
            n_features = 1

        # 确保数据是2D的
        if len(data_np.shape) == 1:
            data_np = data_np.reshape(-1, 1)

        # 检查特征数
        input_features = data_np.shape[1]

        # 如果输入特征数不等于原始特征数，需要填充
        if input_features != n_features:
            if input_features == 1 and n_features > 1:
                # 创建完整特征数组
                full_data = np.zeros((data_np.shape[0], n_features))
                if self.features == 'S':
                    # 单变量模式，目标列在第一列
                    full_data[:, 0] = data_np[:, 0]
                else:
                    # 多变量模式，目标列在最后一列
                    full_data[:, -1] = data_np[:, 0]
                data_np = full_data
            else:
                raise ValueError(f"输入特征数({input_features})与训练特征数({n_features})不匹配")

        # 进行反标准化
        return self.scaler.inverse_transform(data_np)


class Dataset_H2S(Dataset):
    def __init__(self, root_path, flag='train', size=None,
                 features='MS', data_path='SRU_data.txt',
                 target='6', scale=False, timeenc=0, freq='h', cycle=None):
        # size [seq_len, label_len, pred_len]
        if size is None:
            self.seq_len = 6
            self.label_len = 6
            self.pred_len = 1
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['train', 'test', 'val', 'pred']
        # val 映射到 test（无独立验证集）
        type_map = {'train': 0, 'test': 1, 'val': 1, 'pred': 1}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.cycle = cycle

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        # 数据已经是归一化后的，默认 scale=False
        self.scaler = StandardScaler()  # 即使 scale=False 也实例化，以兼容 inverse_transform 调用

        # SRU_data.txt 有 7 列，第一行是列名（1,2,3,4,5,6,7），可能是空格/制表符分隔
        df_raw = pd.read_csv(os.path.join(self.root_path, self.data_path),
                             delim_whitespace=True, header=0)

        # 总共 7 列，输入取前 6 列（索引 0~5），第 7 列（索引 6）舍弃
        # 目标列为第 6 列（列名 '6'，索引 5）
        if self.features == 'M' or self.features == 'MS':
            # 多变量：使用前 6 列（包含目标列 '6'）
            df_data = df_raw.iloc[:, :6].values  # shape: (N, 6)
        elif self.features == 'S':
            # 单变量：只使用目标列（第 6 列，索引 5）
            df_data = df_raw.iloc[:, 5:6].values  # shape: (N, 1)
        else:
            raise ValueError("features only support 'M', 'MS', 'S'")

        # 训练集 80%，测试集 20%，无独立验证集
        num_train = int(len(df_raw) * 0.8)
        num_test = len(df_raw) - num_train

        border1s = [0, num_train - self.seq_len]
        border2s = [num_train, len(df_raw)]

        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        # 归一化处理（数据已归一化，默认不进行额外归一化）
        if self.scale:
            train_data = df_data[:num_train]
            self.scaler.fit(train_data)
            data = self.scaler.transform(df_data)
        else:
            data = df_data.astype(float)

        # 没有时间列，因此时间特征全部设为 0（维度固定为 4，与常见 timeenc=0 兼容）
        length = border2 - border1
        time_feature_dim = 4
        data_stamp = np.zeros((length, time_feature_dim), dtype=float)

        self.data_x = data[border1:border2]
        self.data_y = data[border1:border2]
        self.data_stamp = data_stamp

        # cycle 特征处理：完全按照 Dataset_Custom 的默认处理
        self.cycle_index = (np.arange(len(data)) % self.cycle)[border1:border2]

    def __getitem__(self, index):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin:s_end]
        seq_y = self.data_y[r_begin:r_end]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        cycle_index = torch.tensor(self.cycle_index[s_end])

        return seq_x, seq_y, seq_x_mark, seq_y_mark, cycle_index

    def __len__(self):
        return len(self.data_x) - self.seq_len - self.pred_len + 1

    def inverse_transform(self, data):
        return data


class Dataset_SO2(Dataset):
    def __init__(self, root_path, flag='train', size=None,
                 features='MS', data_path='SRU_data.txt',
                 target='7', scale=False, timeenc=0, freq='h', cycle=None):
        # size [seq_len, label_len, pred_len]
        if size is None:
            self.seq_len = 6
            self.label_len = 6
            self.pred_len = 1
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['train', 'test', 'val', 'pred']
        # val 映射到 test（无独立验证集）
        type_map = {'train': 0, 'test': 1, 'val': 1, 'pred': 1}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.cycle = cycle

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        # 数据已经是归一化后的，默认 scale=False
        self.scaler = StandardScaler()  # 即使 scale=False 也实例化，以兼容 inverse_transform 调用

        # SRU_data.txt 有 7 列，第一行是列名（1,2,3,4,5,6,7），可能是空格/制表符分隔
        df_raw = pd.read_csv(os.path.join(self.root_path, self.data_path),
                             delim_whitespace=True, header=0)

        # 总共 7 列，输入取前 5 列（索引 0~4） + 第 7 列（索引 6），第 6 列（索引 5）舍弃
        # 目标列为第 7 列（列名 '7'，原索引 6）
        if self.features == 'M' or self.features == 'MS':
            # 多变量：使用列 1-5 + 7（索引 [0,1,2,3,4,6]），目标为最后一列
            selected_cols = [0, 1, 2, 3, 4, 6]
            df_data = df_raw.iloc[:, selected_cols].values  # shape: (N, 6)
        elif self.features == 'S':
            # 单变量：只使用目标列（第 7 列，原索引 6）
            df_data = df_raw.iloc[:, 6:7].values  # shape: (N, 1)
        else:
            raise ValueError("features only support 'M', 'MS', 'S'")

        # 训练集 80%，测试集 20%，无独立验证集
        num_train = int(len(df_raw) * 0.8)
        num_test = len(df_raw) - num_train

        border1s = [0, num_train - self.seq_len]
        border2s = [num_train, len(df_raw)]

        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        # 归一化处理（数据已归一化，默认不进行额外归一化）
        if self.scale:
            train_data = df_data[:num_train]
            self.scaler.fit(train_data)
            data = self.scaler.transform(df_data)
        else:
            data = df_data.astype(float)

        # 没有时间列，因此时间特征全部设为 0（维度固定为 4，与常见 timeenc=0 兼容）
        length = border2 - border1
        time_feature_dim = 4
        data_stamp = np.zeros((length, time_feature_dim), dtype=float)

        self.data_x = data[border1:border2]
        self.data_y = data[border1:border2]
        self.data_stamp = data_stamp

        # cycle 特征处理：完全按照 Dataset_Custom 的默认处理
        self.cycle_index = (np.arange(len(data)) % self.cycle)[border1:border2]

    def __getitem__(self, index):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin:s_end]
        seq_y = self.data_y[r_begin:r_end]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        cycle_index = torch.tensor(self.cycle_index[s_end])

        return seq_x, seq_y, seq_x_mark, seq_y_mark, cycle_index

    def __len__(self):
        return len(self.data_x) - self.seq_len - self.pred_len + 1

    def inverse_transform(self, data):
        # 如果 scale=False（默认），直接返回原数据（数据已归一化）
        # 如果 scale=True，也支持反归一化
        if self.scale:
            return self.scaler.inverse_transform(data)
        else:
            return data


## TODO add cycle
class Dataset_Pred(Dataset):
    def __init__(self, root_path, flag='pred', size=None,
                 features='S', data_path='ETTh1.csv',
                 target='OT', scale=True, inverse=False, timeenc=0, freq='15min', cols=None):
        # size [seq_len, label_len, pred_len]
        # info
        if size == None:
            self.seq_len = 24 * 4 * 4
            self.label_len = 24 * 4
            self.pred_len = 24 * 4
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['pred']

        self.features = features
        self.target = target
        self.scale = scale
        self.inverse = inverse
        self.timeenc = timeenc
        self.freq = freq
        self.cols = cols
        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path,
                                          self.data_path))
        '''
        df_raw.columns: ['date', ...(other features), target feature]
        '''
        if self.cols:
            cols = self.cols.copy()
            cols.remove(self.target)
        else:
            cols = list(df_raw.columns)
            cols.remove(self.target)
            cols.remove('date')
        df_raw = df_raw[['date'] + cols + [self.target]]
        border1 = len(df_raw) - self.seq_len
        border2 = len(df_raw)

        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns[1:]
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]

        if self.scale:
            self.scaler.fit(df_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        tmp_stamp = df_raw[['date']][border1:border2]
        tmp_stamp['date'] = pd.to_datetime(tmp_stamp.date)
        pred_dates = pd.date_range(tmp_stamp.date.values[-1], periods=self.pred_len + 1, freq=self.freq)

        df_stamp = pd.DataFrame(columns=['date'])
        df_stamp.date = list(tmp_stamp.date.values) + list(pred_dates[1:])
        if self.timeenc == 0:
            df_stamp['month'] = df_stamp.date.apply(lambda row: row.month, 1)
            df_stamp['day'] = df_stamp.date.apply(lambda row: row.day, 1)
            df_stamp['weekday'] = df_stamp.date.apply(lambda row: row.weekday(), 1)
            df_stamp['hour'] = df_stamp.date.apply(lambda row: row.hour, 1)
            df_stamp['minute'] = df_stamp.date.apply(lambda row: row.minute, 1)
            df_stamp['minute'] = df_stamp.minute.map(lambda x: x // 15)
            data_stamp = df_stamp.drop(['date'], 1).values
        elif self.timeenc == 1:
            data_stamp = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = data_stamp.transpose(1, 0)

        self.data_x = data[border1:border2]
        if self.inverse:
            self.data_y = df_data.values[border1:border2]
        else:
            self.data_y = data[border1:border2]
        self.data_stamp = data_stamp

    def __getitem__(self, index):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin:s_end]
        if self.inverse:
            seq_y = self.data_x[r_begin:r_begin + self.label_len]
        else:
            seq_y = self.data_y[r_begin:r_begin + self.label_len]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        return seq_x, seq_y, seq_x_mark, seq_y_mark

    def __len__(self):
        return len(self.data_x) - self.seq_len + 1

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)


class Dataset_Solar(Dataset):
    def __init__(self, root_path, flag='train', size=None,
                 features='S', data_path='ETTh1.csv',
                 target='OT', scale=True, timeenc=0, freq='h', seasonal_patterns=None, cycle=None):
        # size [seq_len, label_len, pred_len]
        # info
        self.seq_len = size[0]
        self.label_len = size[1]
        self.pred_len = size[2]
        # init
        assert flag in ['train', 'test', 'val']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.cycle = cycle

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = []
        with open(os.path.join(self.root_path, self.data_path), "r", encoding='utf-8') as f:
            for line in f.readlines():
                line = line.strip('\n').split(',')
                data_line = np.stack([float(i) for i in line])
                df_raw.append(data_line)
        df_raw = np.stack(df_raw, 0)
        df_raw = pd.DataFrame(df_raw)

        num_train = int(len(df_raw) * 0.7)
        num_test = int(len(df_raw) * 0.2)
        num_valid = int(len(df_raw) * 0.1)
        border1s = [0, num_train - self.seq_len, len(df_raw) - num_test - self.seq_len]
        border2s = [num_train, num_train + num_valid, len(df_raw)]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        df_data = df_raw.values

        if self.scale:
            train_data = df_data[border1s[0]:border2s[0]]
            self.scaler.fit(train_data)
            data = self.scaler.transform(df_data)
        else:
            data = df_data

        self.data_x = data[border1:border2]
        self.data_y = data[border1:border2]

        # add cycle
        self.cycle_index = (np.arange(len(data)) % self.cycle)[border1:border2]

    def __getitem__(self, index):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin:s_end]
        seq_y = self.data_y[r_begin:r_end]
        seq_x_mark = torch.zeros((seq_x.shape[0], 1))
        seq_y_mark = torch.zeros((seq_x.shape[0], 1))

        cycle_index = torch.tensor(self.cycle_index[s_end])

        return seq_x, seq_y, seq_x_mark, seq_y_mark, cycle_index

    def __len__(self):
        return len(self.data_x) - self.seq_len - self.pred_len + 1

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)


class Dataset_PEMS(Dataset):
    def __init__(self, root_path, flag='train', size=None,
                 features='S', data_path='ETTh1.csv',
                 target='OT', scale=True, timeenc=0, freq='h', cycle=None):
        # size [seq_len, label_len, pred_len]
        # info
        self.seq_len = size[0]
        self.label_len = size[1]
        self.pred_len = size[2]
        # init
        assert flag in ['train', 'test', 'val']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.cycle = cycle

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        self.scaler = StandardScaler()
        data_file = os.path.join(self.root_path, self.data_path)
        data = np.load(data_file, allow_pickle=True)
        data = data['data'][:, :, 0]

        num_train = int(len(data) * 0.6)
        num_test = int(len(data) * 0.2)
        num_valid = int(len(data) * 0.2)
        border1s = [0, num_train - self.seq_len, len(data) - num_test - self.seq_len]
        border2s = [num_train, num_train + num_valid, len(data)]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.scale:
            train_data = data[border1s[0]:border2s[0]]
            self.scaler.fit(train_data)
            data = self.scaler.transform(data)

        self.data_x = data[border1:border2]
        self.data_y = data[border1:border2]

        # add cycle
        self.cycle_index = (np.arange(len(data)) % self.cycle)[border1:border2]

    def __getitem__(self, index):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin:s_end]
        seq_y = self.data_y[r_begin:r_end]
        seq_x_mark = torch.zeros((seq_x.shape[0], 1))
        seq_y_mark = torch.zeros((seq_x.shape[0], 1))

        cycle_index = torch.tensor(self.cycle_index[s_end])

        return seq_x, seq_y, seq_x_mark, seq_y_mark, cycle_index

    def __len__(self):
        return len(self.data_x) - self.seq_len - self.pred_len + 1

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)


class Dataset_ELE(Dataset):
    def __init__(self, root_path, flag='train', size=None,
                 features='MS', data_path='CL_denoised.csv',
                 target='CL', scale=True, timeenc=0, freq='h', cycle=None):
        # size [seq_len, label_len, pred_len]
        # info
        if size == None:
            self.seq_len = 5
            self.label_len = 5
            self.pred_len = 1
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        # 修改：与 Dataset_CONTINU 一致，支持 train / val / test 三种划分
        assert flag in ['train', 'val', 'test']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.cycle = cycle

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

        # 记录特征数
        if self.features == 'S':
            self.n_features = 1
        else:
            # 从scaler中获取特征数
            if hasattr(self.scaler, 'mean_'):
                self.n_features = len(self.scaler.mean_)
            else:
                # 从data中推断
                if hasattr(self, 'data_x'):
                    self.n_features = self.data_x.shape[1]
                else:
                    self.n_features = None

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path, self.data_path))

        '''
        假设数据没有时间列，只包含特征列
        df_raw.columns: [feature1, feature2, ..., target feature]
        '''
        # 检查是否包含目标列；target 不做修改，仍然使用 run.py / 参数中传入的目标列
        if self.target not in df_raw.columns:
            raise ValueError(f"Target column '{self.target}' not found in data")

        cols = list(df_raw.columns)
        cols.remove(self.target)
        # 将目标列放在最后，保证 features='MS' 时预测目标仍然在最后一维
        df_raw = df_raw[cols + [self.target]]

        # 修改：与 Dataset_CONTINU 一致，采用 70% train, 10% val, 20% test
        num_train = int(len(df_raw) * 0.7)
        num_vali = int(len(df_raw) * 0.1)
        num_test = len(df_raw) - num_train - num_vali

        # val/test 前面各额外保留 seq_len 个历史点，用于构造验证集/测试集第一个窗口的输入
        border1s = [
            0,
            num_train - self.seq_len,
            num_train + num_vali - self.seq_len
        ]
        border2s = [
            num_train,
            num_train + num_vali,
            len(df_raw)
        ]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns  # 所有列都是数据列，目标列在最后
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]
        else:
            raise ValueError("features only support 'M', 'MS', 'S'")

        if self.scale:
            train_data = df_data[border1s[0]:border2s[0]]
            self.scaler.fit(train_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        # 数据没有时间列，继续沿用原来的全0时间戳处理方式
        data_len = border2 - border1
        if self.timeenc == 0:
            # 创建全0的时间特征（month, day, weekday, hour）
            data_stamp = np.zeros((data_len, 4))
        elif self.timeenc == 1:
            # 创建全0的时间编码（具体维度取决于time_features函数）
            # 这里假设time_features返回6个特征（根据常见实现）
            data_stamp = np.zeros((data_len, 6))
        else:
            # 如果不使用时间编码，创建空的数组
            data_stamp = np.zeros((data_len, 0))

        self.data_x = data[border1:border2]
        self.data_y = data[border1:border2]
        self.data_stamp = data_stamp

        # add cycle
        if self.cycle is not None:
            self.cycle_index = (np.arange(len(data)) % self.cycle)[border1:border2]
        else:
            self.cycle_index = np.zeros(len(self.data_x))

    def __getitem__(self, index):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin:s_end]
        seq_y = self.data_y[r_begin:r_end]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        cycle_index = torch.tensor(self.cycle_index[s_end])

        return seq_x, seq_y, seq_x_mark, seq_y_mark, cycle_index

    def __len__(self):
        return len(self.data_x) - self.seq_len - self.pred_len + 1

    def inverse_transform(self, data):
        """反标准化数据

        Args:
            data: 要反标准化的数据，形状应为 (n_samples, n_features)

        Returns:
            反标准化后的数据
        """
        if not self.scale:
            return data

        # 确保数据是numpy数组
        data_np = np.array(data)

        # 获取原始特征数
        if hasattr(self, 'n_features') and self.n_features is not None:
            n_features = self.n_features
        elif hasattr(self.scaler, 'mean_'):
            n_features = len(self.scaler.mean_)
        else:
            # 默认假设单变量
            n_features = 1

        # 确保数据是2D的
        if len(data_np.shape) == 1:
            data_np = data_np.reshape(-1, 1)

        # 检查特征数
        input_features = data_np.shape[1]

        # 如果输入特征数不等于原始特征数，需要填充
        if input_features != n_features:
            if input_features == 1 and n_features > 1:
                # 创建完整特征数组
                full_data = np.zeros((data_np.shape[0], n_features))
                if self.features == 'S':
                    # 单变量模式，目标列在第一列
                    full_data[:, 0] = data_np[:, 0]
                else:
                    # 多变量模式，目标列在最后一列
                    full_data[:, -1] = data_np[:, 0]
                data_np = full_data
            else:
                raise ValueError(f"输入特征数({input_features})与训练特征数({n_features})不匹配")

        # 进行反标准化
        return self.scaler.inverse_transform(data_np)



class Dataset_EDD(Dataset):
    def __init__(self, root_path, flag='train', size=None,
                 features='MS', data_path='Electricity demand dataset.csv',
                 target=None, scale=True, timeenc=0, freq='h', cycle=None):
        # size [seq_len, label_len, pred_len]
        # info
        if size == None:
            self.seq_len = 5
            self.label_len = 5
            self.pred_len = 1
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        # 修改：与 Dataset_CONTINU 一致，支持 train / val / test 三种划分
        assert flag in ['train', 'val', 'test']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.cycle = cycle

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

        # 记录特征数
        if self.features == 'S':
            self.n_features = 1
        else:
            # 从scaler中获取特征数
            if hasattr(self.scaler, 'mean_'):
                self.n_features = len(self.scaler.mean_)
            else:
                # 从data中推断
                if hasattr(self, 'data_x'):
                    self.n_features = self.data_x.shape[1]
                else:
                    self.n_features = None

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path, self.data_path))

        '''
        假设数据没有时间列，只包含特征列
        df_raw.columns: [feature1, feature2, ..., target feature]
        '''
        # 检查是否包含目标列；target 不做修改，仍然使用 run.py / 参数中传入的目标列
        if self.target not in df_raw.columns:
            raise ValueError(f"Target column '{self.target}' not found in data")

        cols = list(df_raw.columns)
        cols.remove(self.target)
        # 将目标列放在最后，保证 features='MS' 时预测目标仍然在最后一维
        df_raw = df_raw[cols + [self.target]]

        # 修改：与 Dataset_CONTINU 一致，采用 70% train, 10% val, 20% test
        num_train = int(len(df_raw) * 0.7)
        num_vali = int(len(df_raw) * 0.1)
        num_test = len(df_raw) - num_train - num_vali

        # val/test 前面各额外保留 seq_len 个历史点，用于构造验证集/测试集第一个窗口的输入
        border1s = [
            0,
            num_train - self.seq_len,
            num_train + num_vali - self.seq_len
        ]
        border2s = [
            num_train,
            num_train + num_vali,
            len(df_raw)
        ]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns  # 所有列都是数据列，目标列在最后
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]
        else:
            raise ValueError("features only support 'M', 'MS', 'S'")

        if self.scale:
            train_data = df_data[border1s[0]:border2s[0]]
            self.scaler.fit(train_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        # 数据没有时间列，继续沿用原来的全0时间戳处理方式
        data_len = border2 - border1
        if self.timeenc == 0:
            # 创建全0的时间特征（month, day, weekday, hour）
            data_stamp = np.zeros((data_len, 4))
        elif self.timeenc == 1:
            # 创建全0的时间编码（具体维度取决于time_features函数）
            # 这里假设time_features返回6个特征（根据常见实现）
            data_stamp = np.zeros((data_len, 6))
        else:
            # 如果不使用时间编码，创建空的数组
            data_stamp = np.zeros((data_len, 0))

        self.data_x = data[border1:border2]
        self.data_y = data[border1:border2]
        self.data_stamp = data_stamp

        # add cycle
        if self.cycle is not None:
            self.cycle_index = (np.arange(len(data)) % self.cycle)[border1:border2]
        else:
            self.cycle_index = np.zeros(len(self.data_x))

    def __getitem__(self, index):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin:s_end]
        seq_y = self.data_y[r_begin:r_end]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        cycle_index = torch.tensor(self.cycle_index[s_end])

        return seq_x, seq_y, seq_x_mark, seq_y_mark, cycle_index

    def __len__(self):
        return len(self.data_x) - self.seq_len - self.pred_len + 1

    def inverse_transform(self, data):
        """反标准化数据

        Args:
            data: 要反标准化的数据，形状应为 (n_samples, n_features)

        Returns:
            反标准化后的数据
        """
        if not self.scale:
            return data

        # 确保数据是numpy数组
        data_np = np.array(data)

        # 获取原始特征数
        if hasattr(self, 'n_features') and self.n_features is not None:
            n_features = self.n_features
        elif hasattr(self.scaler, 'mean_'):
            n_features = len(self.scaler.mean_)
        else:
            # 默认假设单变量
            n_features = 1

        # 确保数据是2D的
        if len(data_np.shape) == 1:
            data_np = data_np.reshape(-1, 1)

        # 检查特征数
        input_features = data_np.shape[1]

        # 如果输入特征数不等于原始特征数，需要填充
        if input_features != n_features:
            if input_features == 1 and n_features > 1:
                # 创建完整特征数组
                full_data = np.zeros((data_np.shape[0], n_features))
                if self.features == 'S':
                    # 单变量模式，目标列在第一列
                    full_data[:, 0] = data_np[:, 0]
                else:
                    # 多变量模式，目标列在最后一列
                    full_data[:, -1] = data_np[:, 0]
                data_np = full_data
            else:
                raise ValueError(f"输入特征数({input_features})与训练特征数({n_features})不匹配")

        # 进行反标准化
        return self.scaler.inverse_transform(data_np)



class Dataset_CONTINU(Dataset):
    def __init__(self, root_path, flag='train', size=None,
                 features='MS', data_path='continuous dataset.csv',
                 target='nat_demand', scale=True, timeenc=0, freq='h', cycle=None):
        # size [seq_len, label_len, pred_len]
        if size is None:
            self.seq_len = 10
            self.label_len = 6
            self.pred_len = 1
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]

        assert flag in ['train', 'val', 'test']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.cycle = cycle

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

        if self.features == 'S':
            self.n_features = 1
        else:
            if hasattr(self.scaler, 'mean_'):
                self.n_features = len(self.scaler.mean_)
            elif hasattr(self, 'data_x'):
                self.n_features = self.data_x.shape[1]
            else:
                self.n_features = None

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path, self.data_path))

        # 兼容 target 写成 nat-demand 或 nat_demand 的情况
        if self.target not in df_raw.columns:
            if self.target == 'nat-demand' and 'nat_demand' in df_raw.columns:
                self.target = 'nat_demand'
            elif self.target == 'nat_demand' and 'nat-demand' in df_raw.columns:
                df_raw = df_raw.rename(columns={'nat-demand': 'nat_demand'})
                self.target = 'nat_demand'
            else:
                raise ValueError(f"Target column '{self.target}' not found in data")

        # 时间列
        if 'datetime' in df_raw.columns:
            date_col = 'datetime'
        elif 'date' in df_raw.columns:
            date_col = 'date'
        else:
            raise ValueError("No datetime/date column found in data")

        # y 为 nat_demand，x 为 y 后面的所有列；
        # 为了配合 features='MS'，把 target 放到最后一列，这样预测时取最后一维。
        target_pos = df_raw.columns.get_loc(self.target)
        x_cols = list(df_raw.columns[target_pos + 1:])
        x_cols = [c for c in x_cols if c not in [date_col, self.target]]

        df_raw = df_raw[[date_col] + x_cols + [self.target]]

        # 70% train, 10% val, 20% test
        num_train = int(len(df_raw) * 0.7)
        num_vali = int(len(df_raw) * 0.1)
        num_test = len(df_raw) - num_train - num_vali

        border1s = [
            0,
            num_train - self.seq_len,
            num_train + num_vali - self.seq_len
        ]
        border2s = [
            num_train,
            num_train + num_vali,
            len(df_raw)
        ]

        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.features == 'M' or self.features == 'MS':
            # 多变量输入：x 的所有列 + 目标列 y，其中 y 在最后一列
            cols_data = df_raw.columns[1:]
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]
        else:
            raise ValueError("features only support 'M', 'MS', 'S'")

        if self.scale:
            train_data = df_data[border1s[0]:border2s[0]]
            self.scaler.fit(train_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        df_stamp = df_raw[[date_col]][border1:border2].copy()
        df_stamp.columns = ['date']
        df_stamp['date'] = pd.to_datetime(df_stamp['date'])

        if self.timeenc == 0:
            df_stamp['month'] = df_stamp.date.apply(lambda row: row.month, 1)
            df_stamp['day'] = df_stamp.date.apply(lambda row: row.day, 1)
            df_stamp['weekday'] = df_stamp.date.apply(lambda row: row.weekday(), 1)
            df_stamp['hour'] = df_stamp.date.apply(lambda row: row.hour, 1)
            data_stamp = df_stamp.drop(columns=['date']).values
        elif self.timeenc == 1:
            data_stamp = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = data_stamp.transpose(1, 0)
        else:
            data_stamp = np.zeros((border2 - border1, 0))

        self.data_x = data[border1:border2]
        self.data_y = data[border1:border2]
        self.data_stamp = data_stamp

        if self.cycle is not None:
            self.cycle_index = (np.arange(len(data)) % self.cycle)[border1:border2]
        else:
            self.cycle_index = np.zeros(len(self.data_x))

    def __getitem__(self, index):
        s_begin = index
        s_end = s_begin + self.seq_len

        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin:s_end]
        seq_y = self.data_y[r_begin:r_end]

        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        cycle_index = torch.tensor(self.cycle_index[s_end])

        return seq_x, seq_y, seq_x_mark, seq_y_mark, cycle_index

    def __len__(self):
        return len(self.data_x) - self.seq_len - self.pred_len + 1

    def inverse_transform(self, data):
        if not self.scale:
            return data

        data_np = np.array(data)

        if len(data_np.shape) == 1:
            data_np = data_np.reshape(-1, 1)

        if hasattr(self, 'n_features') and self.n_features is not None:
            n_features = self.n_features
        elif hasattr(self.scaler, 'mean_'):
            n_features = len(self.scaler.mean_)
        else:
            n_features = 1

        input_features = data_np.shape[1]

        # features='MS' 时预测输出通常只有目标列，需要补回完整维度再反标准化
        if input_features != n_features:
            if input_features == 1 and n_features > 1:
                full_data = np.zeros((data_np.shape[0], n_features))
                full_data[:, -1] = data_np[:, 0]  # target 在最后一列
                data_np = full_data
            else:
                raise ValueError(f"输入特征数({input_features})与训练特征数({n_features})不匹配")

        return self.scaler.inverse_transform(data_np)