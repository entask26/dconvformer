# import numpy as np
# import os
# import pandas as pd
# from matplotlib import pyplot as plt
# from scipy.stats import norm
#
#
# def plot_truth_vs_pred(truths, preds):
#     """绘制真实值和预测值的拟合程度图并保存"""
#     if len(truths) != len(preds):
#         raise ValueError("The lengths of truths and preds must be the same.")
#
#     # 将列表转换为 NumPy 数组
#     truths = np.array(truths)
#     preds = np.array(preds)
#
#     save_dir = "../save/pictures"
#     picture_name = "Electricity"  # 图片名称
#
#     # 确保保存路径存在
#     os.makedirs(save_dir, exist_ok=True)
#
#     save_line_png = os.path.join(save_dir, f"{picture_name}_line.png")
#     save_scatter_png = os.path.join(save_dir, f"{picture_name}_scatter.png")
#
#     # 散点图和折线图纵轴
#     # lim = 0.7  # H2S
#     # lim = 0.5  #S02
#     lim = max(np.max(truths), np.max(preds))  # 增加10%边距    # CL
#
#     # 绘制折线图---------------------------------------------------------------
#     plt.figure(figsize=(24, 6))  # 图形的大小
#     plt.plot(truths, 'k--', label='True', linewidth=1.5)
#     plt.plot(preds, 'r-', label='Predicted', linewidth=1)
#     plt.xlabel('Sample points', fontsize=14)
#     plt.ylabel(f'{picture_name} Values', fontsize=14)
#     plt.legend(loc='upper left', fontsize=14)  # 图例
#     plt.grid(True, linestyle='--')
#     plt.xlim(0, 1000)
#     plt.ylim(0, lim)
#     plt.savefig(save_line_png, format='png', bbox_inches='tight', dpi=600)
#     plt.close()
#
#     # 绘制散点图---------------------------------------------------------------
#     plt.figure(figsize=(6, 6))  # 图形的大小
#     errors = np.abs(truths - preds)  # 计算误差
#     norm_scatter = plt.Normalize(errors.min(), errors.max())  # 归一化误差
#     cmap = 'Blues_r'  # 颜色映射
#
#     # 绘制散点图，s为每个点的大小
#     scatter = plt.scatter(truths, preds, c=errors, cmap=cmap, norm=norm_scatter, s=70, edgecolors='none',
#                           label=f'{picture_name} Values')
#
#     # 绘制 y=x 参考线
#     plt.plot([0, lim], [0, lim], 'r--', lw=2, label='y=x')
#
#     plt.xlabel('True values', fontsize=14)
#     plt.ylabel('Predicted values', fontsize=14)
#     plt.legend(loc='upper left', fontsize=14)
#     plt.xlim(800, lim)
#     plt.ylim(800, lim)
#     plt.gca().set_aspect('equal', adjustable='box')  # 保持长宽比例为1:1
#     plt.savefig(save_scatter_png, format='png', bbox_inches='tight', dpi=600)
#     plt.close()
#
#     # 误差正态拟合直方图--------------------------------------------------------------------------------------
#     # 计算误差（真实值 - 预测值）
#     errors = np.array(truths) - np.array(preds)
#
#     # 计算统计指标
#     mean_error = np.mean(errors)
#     std_error = np.std(errors)
#
#     # ===== 创建预测误差正态拟合直方图=====
#     plt.figure(figsize=(10, 6))
#
#     bins = np.linspace(np.min(errors), np.max(errors), 150)
#
#     # 绘制柱状图（频率直方图）
#     n, bins, patches = plt.hist(
#         errors,
#         bins=bins,# 柱子数
#         density=False,  # 显示频率而非概率密度
#         alpha=0.7,
#         color='green',  # 柱子颜色
#         edgecolor='black',# 柱子边框颜色
#         linewidth=1,
#         label='Ours'
#     )
#
#     # 计算并绘制正态分布曲线
#     x = np.linspace(min(errors), max(errors), 1000)
#     pdf = norm.pdf(x, mean_error, std_error)
#     # 将概率密度转换为频率数量
#     bin_width = bins[1] - bins[0]
#     scale_factor = len(errors) * bin_width
#
#     # 绘制正态分布曲线
#     plt.plot(
#         x,
#         pdf * scale_factor,
#         color='#006400',
#         linewidth=2,
#         # label='Normal fit'
#     )
#     # 设置横轴范围
#     plt.xlim(-1, 1)
#
#     plt.axvline(x=0, color='k', linestyle='dashed', linewidth=1.5)
#
#     # 设置横轴刻度和标签
#     plt.xticks(np.arange(-1, 1 + 0.2, 0.2))
#     plt.xlabel('Error value', fontsize=14)
#     plt.ylabel('Frequency', fontsize=14)
#     plt.legend(fontsize=12, loc='upper right')
#     plt.grid(True, linestyle='--', alpha=0.7)
#
#     # 保存图片
#     save_path = os.path.join(save_dir, f"{picture_name}_error_histogram.png")
#     plt.savefig(save_path, bbox_inches='tight', dpi=600)
#     plt.close()
#
#     print(f" All the pictures are saved to {save_dir}")
#
# def visualize_predictions_from_csv(csv_path):
#     """
#     从CSV文件读取预测结果并进行可视化
#
#     参数:
#         csv_path (str): predictions.csv文件的路径
#     """
#     # 读取CSV文件
#     df = pd.read_csv(csv_path)
#
#     # 提取真实值和预测值
#     truths = df['True'].values
#     preds = df['Predicted'].values
#
#     # 调用绘图函数
#     plot_truth_vs_pred(truths, preds)
#
#     # 返回提取的数据（可选）
#     return truths, preds
#
#
# if __name__ == "__main__":
#     # 使用示例:
#     # experiment_dir = "results/ELE_1_1_EMAformer_ELE_ftMS_sl15_ll15_pl1_dm64_nh8_el2_dl1_df1024_fc1_ebtimeF_dtTrue_Exp_projection/predictions.csv"
#     # csv_path = os.path.join(experiment_dir, "predictions.csv")
#
#     csv_path = "results/CONTINU_10_1_EMAformer_continu_ftMS_sl3_ll3_pl1_dm64_nh16_el3_dl1_df64_fc1_ebtimeF_dtTrue_Exp_projection/predictions.csv"
#
#     # 确保CSV文件存在
#     if os.path.exists(csv_path):
#         truths, preds = visualize_predictions_from_csv(csv_path)
#     else:
#         print(f"预测文件不存在: {csv_path}")

import numpy as np
import os
import pandas as pd
from matplotlib import pyplot as plt
from scipy.stats import norm


def plot_truth_vs_pred(truths, preds):
    """绘制真实值和预测值的拟合程度图并保存"""
    if len(truths) != len(preds):
        raise ValueError("The lengths of truths and preds must be the same.")

    # 将列表转换为 NumPy 数组
    truths = np.array(truths)
    preds = np.array(preds)

    save_dir = "../save/pictures"
    picture_name = "Electricity"  # 图片保存名称，不影响图中的label名称

    # 确保保存路径存在
    os.makedirs(save_dir, exist_ok=True)

    save_line_png = os.path.join(save_dir, f"{picture_name}_line.png")
    save_scatter_png = os.path.join(save_dir, f"{picture_name}_scatter.png")

    # 坐标轴范围
    lim = max(np.max(truths), np.max(preds))

    # 绘制折线图---------------------------------------------------------------
    plt.figure(figsize=(24, 6))
    plt.plot(truths, 'k--', label='True', linewidth=1.5)
    plt.plot(preds, 'r-', label='Predicted', linewidth=1)

    # 与图片保持一致
    plt.xlabel('Sample points', fontsize=14)
    plt.ylabel('Energy demand values', fontsize=14)

    plt.legend(loc='upper left', fontsize=14)
    plt.grid(True, linestyle='--')
    plt.xlim(0, 1000)
    plt.ylim(0, 50000)
    plt.savefig(save_line_png, format='png', bbox_inches='tight', dpi=600)
    plt.close()

    # 绘制散点图---------------------------------------------------------------
    plt.figure(figsize=(6, 6))

    errors = np.abs(truths - preds)
    norm_scatter = plt.Normalize(errors.min(), errors.max())
    cmap = 'Blues_r'

    # 与图片保持一致：散点图label为 Ours
    plt.scatter(
        truths,
        preds,
        c=errors,
        cmap=cmap,
        norm=norm_scatter,
        s=70,
        edgecolors='none',
        label='Ours'
    )

    # 绘制 y=x 参考线，与图片保持一致
    plt.plot([0, 45000], [0, 45000], 'r--', lw=2, label='y=x')

    # 与图片保持一致
    plt.xlabel('True values', fontsize=14)
    plt.ylabel('Predicted values', fontsize=14)

    plt.legend(loc='upper left', fontsize=14)
    plt.xlim(15000, 45000)
    plt.ylim(15000, 45000)
    plt.gca().set_aspect('equal', adjustable='box')
    plt.savefig(save_scatter_png, format='png', bbox_inches='tight', dpi=600)
    plt.close()

    # 误差正态拟合直方图---------------------------------------------------------
    errors = np.array(truths) - np.array(preds)

    mean_error = np.mean(errors)
    std_error = np.std(errors)

    plt.figure(figsize=(10, 6))

    bins = np.linspace(np.min(errors), np.max(errors), 150)

    n, bins, patches = plt.hist(
        errors,
        bins=bins,
        density=False,
        alpha=0.7,
        color='green',
        edgecolor='black',
        linewidth=1,
        label='Ours'
    )

    x = np.linspace(min(errors), max(errors), 1000)
    pdf = norm.pdf(x, mean_error, std_error)

    bin_width = bins[1] - bins[0]
    scale_factor = len(errors) * bin_width

    plt.plot(
        x,
        pdf * scale_factor,
        color='#006400',
        linewidth=2,
    )

    plt.xlim(-1, 1)
    plt.axvline(x=0, color='k', linestyle='dashed', linewidth=1.5)

    plt.xticks(np.arange(-1, 1 + 0.2, 0.2))
    plt.xlabel('Error value', fontsize=14)
    plt.ylabel('Frequency', fontsize=14)
    plt.legend(fontsize=12, loc='upper right')
    plt.grid(True, linestyle='--', alpha=0.7)

    save_path = os.path.join(save_dir, f"{picture_name}_error_histogram.png")
    plt.savefig(save_path, bbox_inches='tight', dpi=600)
    plt.close()

    print(f"All the pictures are saved to {save_dir}")


def visualize_predictions_from_csv(csv_path):
    """
    从CSV文件读取预测结果并进行可视化

    参数:
        csv_path (str): predictions.csv文件的路径
    """
    df = pd.read_csv(csv_path)

    truths = df['True'].values
    preds = df['Predicted'].values

    plot_truth_vs_pred(truths, preds)

    return truths, preds


if __name__ == "__main__":
    csv_path = "results/EDD_1_1_EMAformer_EDD_ftMS_sl3_ll3_pl1_dm128_nh16_el3_dl1_df128_fc1_ebtimeF_dtTrue_Exp_projection/predictions.csv"

    if os.path.exists(csv_path):
        truths, preds = visualize_predictions_from_csv(csv_path)
    else:
        print(f"预测文件不存在: {csv_path}")