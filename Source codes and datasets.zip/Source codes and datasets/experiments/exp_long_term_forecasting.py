from sympy import Ci
from data_provider.data_factory import data_provider
from experiments.exp_basic import Exp_Basic
from utils.tools import EarlyStopping, adjust_learning_rate, visual
from utils.metrics import metric
import torch
import torch.nn as nn
from torch import optim
import os
import time
import warnings
import numpy as np
import pandas as pd  # 添加pandas库用于保存CSV

warnings.filterwarnings('ignore')


class Exp_Long_Term_Forecast(Exp_Basic):
    def __init__(self, args):
        super(Exp_Long_Term_Forecast, self).__init__(args)

    def _build_model(self):
        model = self.model_dict[self.args.model].Model(self.args).float()

        if self.args.use_multi_gpu and self.args.use_gpu:
            model = nn.DataParallel(model, device_ids=self.args.device_ids)
        return model

    def _get_data(self, flag):
        data_set, data_loader = data_provider(self.args, flag)
        return data_set, data_loader

    def _select_optimizer(self):
        model_optim = optim.Adam(self.model.parameters(), lr=self.args.learning_rate)
        return model_optim

    def _select_criterion(self):
        criterion = nn.L1Loss()
        return criterion

    def vali(self, vali_data, vali_loader, criterion):
        total_loss = []
        self.model.eval()
        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark, batch_cycle) in enumerate(vali_loader):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)
                batch_cycle = batch_cycle.int().to(self.device)
                if 'PEMS' in self.args.data or 'Solar' in self.args.data:
                    batch_x_mark = None
                    batch_y_mark = None
                else:
                    batch_x_mark = batch_x_mark.float().to(self.device)
                    batch_y_mark = batch_y_mark.float().to(self.device)

                # decoder input
                dec_inp = torch.zeros_like(batch_y[:, -self.args.pred_len:, :]).float()
                dec_inp = torch.cat([batch_y[:, :self.args.label_len, :], dec_inp], dim=1).float().to(self.device)
                # encoder - decoder
                if self.args.use_amp:
                    with torch.cuda.amp.autocast():
                        if self.args.output_attention:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark, batch_cycle)[0]
                        else:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark, batch_cycle)
                else:
                    if self.args.output_attention:
                        outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark, batch_cycle)[0]
                    else:
                        outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark, batch_cycle)
                f_dim = -1 if self.args.features == 'MS' else 0
                outputs = outputs[:, -self.args.pred_len:, f_dim:]
                batch_y = batch_y[:, -self.args.pred_len:, f_dim:].to(self.device)

                pred = outputs.detach().cpu()
                true = batch_y.detach().cpu()

                loss = criterion(pred, true)

                total_loss.append(loss.item())
        total_loss = np.average(total_loss)
        self.model.train()
        return total_loss

    def train(self, setting):
        train_data, train_loader = self._get_data(flag='train')
        vali_data, vali_loader = self._get_data(flag='val')
        # test_data, test_loader = self._get_data(flag='test')

        path = os.path.join(self.args.checkpoints, setting)
        if not os.path.exists(path):
            os.makedirs(path)

        time_now = time.time()

        train_steps = len(train_loader)

        # 移除早停机制，改用训练损失保存最佳模型
        best_val_loss = float('inf')

        # 创建训练损失记录列表
        train_loss_history = []
        vali_loss_history = []

        model_optim = self._select_optimizer()
        criterion = self._select_criterion()
        # if  self.args.lradj == 'type1':
        #     print('using type1 lradj')
        #     scheduler = optim.lr_scheduler.ExponentialLR(model_optim, gamma=0.5)
        if self.args.lradj == 'type3':
            scheduler = optim.lr_scheduler.MultiStepLR(model_optim, milestones=[5, 10, 15, 20], gamma=0.1)

        if self.args.use_amp:
            scaler = torch.cuda.amp.GradScaler()

        for epoch in range(self.args.train_epochs):
            iter_count = 0
            train_loss = []

            self.model.train()
            epoch_time = time.time()
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark, batch_cycle) in enumerate(train_loader):
                iter_count += 1
                model_optim.zero_grad()
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)
                batch_cycle = batch_cycle.int().to(self.device)
                if 'PEMS' in self.args.data or 'Solar' in self.args.data:
                    batch_x_mark = None
                    batch_y_mark = None
                else:
                    batch_x_mark = batch_x_mark.float().to(self.device)
                    batch_y_mark = batch_y_mark.float().to(self.device)

                # decoder input
                dec_inp = torch.zeros_like(batch_y[:, -self.args.pred_len:, :]).float()
                dec_inp = torch.cat([batch_y[:, :self.args.label_len, :], dec_inp], dim=1).float().to(self.device)

                # encoder - decoder
                if self.args.use_amp:
                    with torch.cuda.amp.autocast():
                        if self.args.output_attention:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark, batch_cycle)[0]
                        else:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark, batch_cycle)

                        f_dim = -1 if self.args.features == 'MS' else 0
                        outputs = outputs[:, -self.args.pred_len:, f_dim:]
                        batch_y = batch_y[:, -self.args.pred_len:, f_dim:].to(self.device)
                        loss = criterion(outputs, batch_y)
                        train_loss.append(loss.item())
                else:
                    if self.args.output_attention:
                        outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark, batch_cycle)[0]
                    else:
                        outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark, batch_cycle)

                    f_dim = -1 if self.args.features == 'MS' else 0
                    outputs = outputs[:, -self.args.pred_len:, f_dim:]
                    batch_y = batch_y[:, -self.args.pred_len:, f_dim:].to(self.device)
                    loss = criterion(outputs, batch_y)
                    train_loss.append(loss.item())

                if (i + 1) % 100 == 0:
                    print("\titers: {0}, epoch: {1} | loss: {2:.7f}".format(i + 1, epoch + 1, loss.item()))
                    speed = (time.time() - time_now) / iter_count
                    left_time = speed * ((self.args.train_epochs - epoch) * train_steps - i)
                    print('\tspeed: {:.4f}s/iter; left time: {:.4f}s'.format(speed, left_time))
                    iter_count = 0
                    time_now = time.time()

                if self.args.use_amp:
                    scaler.scale(loss).backward()
                    scaler.step(model_optim)
                    scaler.update()
                else:
                    loss.backward()
                    model_optim.step()

            print("Epoch: {} cost time: {}".format(epoch + 1, time.time() - epoch_time))
            train_loss = np.average(train_loss)

            # 记录训练损失，必须加这一行
            train_loss_history.append(train_loss)

            vali_loss = self.vali(vali_data, vali_loader, criterion)
            vali_loss_history.append(vali_loss)

            print("Epoch: {0}, Steps: {1} | Train Loss: {2:.7f} | Vali Loss: {3:.7f}".format(
                epoch + 1, train_steps, train_loss, vali_loss))

            # 根据验证集损失保存最佳模型
            if vali_loss < best_val_loss:
                best_val_loss = vali_loss
                torch.save(self.model.state_dict(), path + '/' + 'checkpoint.pth')
                print(f"Best model saved with vali loss: {vali_loss:.7f}")

            if self.args.lradj == 'type1':
                adjust_learning_rate(model_optim, epoch + 1, self.args)
            elif self.args.lradj == 'type3':
                scheduler.step()
                current_lr = model_optim.param_groups[0]['lr']
                print(f"Epoch {epoch + 1}: learning rate = {current_lr:.6f}")
            # get_cka(self.args, setting, self.model, train_loader, self.device, epoch)

        # 训练结束后保存训练损失到CSV文件
        train_loss_df = pd.DataFrame({
            'epoch': range(1, len(train_loss_history) + 1),
            'train_loss': train_loss_history,
            'vali_loss': vali_loss_history
        })
        train_loss_csv_path = path + '/train_loss.csv'
        train_loss_df.to_csv(train_loss_csv_path, index=False)
        print(f"Training loss saved to {train_loss_csv_path}")

        # 训练结束后加载最佳模型
        best_model_path = path + '/' + 'checkpoint.pth'
        self.model.load_state_dict(torch.load(best_model_path))

        return self.model

    def test(self, setting, test=0):
        test_data, test_loader = self._get_data(flag='test')
        if test:
            print('loading model')
            self.model.load_state_dict(torch.load(os.path.join('./checkpoints/' + setting, 'checkpoint.pth')))

        preds = []
        trues = []
        folder_path = './test_results/' + setting + '/'
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        self.model.eval()
        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark, batch_cycle) in enumerate(test_loader):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)
                batch_cycle = batch_cycle.int().to(self.device)

                # 处理时间标记
                if 'PEMS' in self.args.data or 'Solar' in self.args.data:
                    batch_x_mark = None
                    batch_y_mark = None
                else:
                    batch_x_mark = batch_x_mark.float().to(self.device)
                    batch_y_mark = batch_y_mark.float().to(self.device)

                # decoder input
                dec_inp = torch.zeros_like(batch_y[:, -self.args.pred_len:, :]).float()
                dec_inp = torch.cat([batch_y[:, :self.args.label_len, :], dec_inp], dim=1).float().to(self.device)

                # encoder - decoder
                if self.args.use_amp:
                    with torch.cuda.amp.autocast():
                        if self.args.output_attention:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark, batch_cycle)[0]
                        else:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark, batch_cycle)
                else:
                    if self.args.output_attention:
                        outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark, batch_cycle)[0]
                    else:
                        outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark, batch_cycle)

                f_dim = -1 if self.args.features == 'MS' else 0
                outputs = outputs[:, -self.args.pred_len:, f_dim:]
                batch_y = batch_y[:, -self.args.pred_len:, f_dim:].to(self.device)

                # 保存原始输出
                outputs_np = outputs.detach().cpu().numpy()
                batch_y_np = batch_y.detach().cpu().numpy()

                # 反标准化处理
                if test_data.scale and self.args.inverse:
                    batch_size, pred_len, n_output_features = outputs_np.shape

                    # 使用数据集的inverse_transform方法
                    # 将3D数组转换为2D进行反标准化
                    outputs_2d = outputs_np.reshape(-1, n_output_features)
                    outputs_denorm = test_data.inverse_transform(outputs_2d)

                    # 检查反标准化后的特征数
                    n_features_denorm = outputs_denorm.shape[1]

                    # 如果反标准化后有多特征，只取目标列
                    if n_features_denorm > 1:
                        if self.args.features == 'MS':
                            # 多变量预测单变量，目标列在最后一列
                            outputs_denorm_target = outputs_denorm[:, -1]
                        else:
                            # 单变量模式，目标列在第一列
                            outputs_denorm_target = outputs_denorm[:, 0]

                        # 重塑回3D，保持目标列
                        outputs_np = outputs_denorm_target.reshape(batch_size, pred_len, 1)
                    else:
                        # 直接重塑回3D
                        outputs_np = outputs_denorm.reshape(batch_size, pred_len, n_features_denorm)

                    # 同样处理真实值
                    batch_y_2d = batch_y_np.reshape(-1, n_output_features)
                    batch_y_denorm = test_data.inverse_transform(batch_y_2d)

                    if batch_y_denorm.shape[1] > 1:
                        if self.args.features == 'MS':
                            batch_y_denorm_target = batch_y_denorm[:, -1]
                        else:
                            batch_y_denorm_target = batch_y_denorm[:, 0]

                        batch_y_np = batch_y_denorm_target.reshape(batch_size, pred_len, 1)
                    else:
                        batch_y_np = batch_y_denorm.reshape(batch_size, pred_len, 1)

                preds.append(outputs_np)
                trues.append(batch_y_np)

        # 合并所有batch的预测结果
        preds = np.concatenate(preds, axis=0)
        trues = np.concatenate(trues, axis=0)

        print('测试形状 - preds:', preds.shape, 'trues:', trues.shape)

        # 保存预测值和真实值为CSV文件
        try:
            import pandas as pd
            # 展平数据
            if len(preds.shape) == 3:
                # 取目标列并展平
                if self.args.features == 'MS':
                    preds_flat = preds[:, :, -1].flatten()
                    trues_flat = trues[:, :, -1].flatten()
                else:
                    preds_flat = preds[:, :, 0].flatten()
                    trues_flat = trues[:, :, 0].flatten()
            else:
                preds_flat = preds.flatten()
                trues_flat = trues.flatten()

            # 创建DataFrame
            results_df = pd.DataFrame({
                'True': trues_flat,
                'Predicted': preds_flat
            })

            # 保存到results文件夹
            results_folder_path = './results/' + setting + '/'
            if not os.path.exists(results_folder_path):
                os.makedirs(results_folder_path)

            results_csv_path = results_folder_path + 'predictions.csv'
            results_df.to_csv(results_csv_path, index=False)
            print(f"预测结果已保存至: {results_csv_path}")
            print(f"数据形状: {results_df.shape}")

        except ImportError:
            print("错误: pandas未安装，无法保存CSV文件。")
        except Exception as e:
            print(f"保存CSV时出错: {e}")

        # ====================== 原有指标计算 ======================
        r2, mae, rmse = metric(preds, trues)

        # ====================== 新增：MAPE、MASE、CV-RMSE ======================
        # 1. 展平（与您保存 predictions.csv 的逻辑一致）
        if len(preds.shape) == 3:
            if self.args.features == 'MS':
                preds_flat = preds[:, :, -1].flatten()
                trues_flat = trues[:, :, -1].flatten()
            else:
                preds_flat = preds[:, :, 0].flatten()
                trues_flat = trues[:, :, 0].flatten()
        else:
            preds_flat = preds.flatten()
            trues_flat = trues.flatten()

        # 2. MAPE（避免除零）
        mape = np.mean(np.abs((trues_flat - preds_flat) / (trues_flat + 1e-8))) * 100

        # 3. CV-RMSE
        mean_true = np.mean(np.abs(trues_flat))
        cv_rmse = (rmse / mean_true * 100) if mean_true > 0 else np.nan

        # 4. MASE（非季节性简化版，使用测试集自身的 naive 缩放因子）
        #    如果您的任务有明显季节性，可后续再改成 seasonal MASE
        if len(trues_flat) > 1:
            naive_mae = np.mean(np.abs(np.diff(trues_flat)))  # |y_t - y_{t-1}|
            mase = mae / naive_mae if naive_mae > 0 else np.nan
        else:
            mase = np.nan

        # ====================== 打印与保存 ======================
        print(f'\n测试结果: r2={r2:.4f}, mae={mae:.4f}, rmse={rmse:.4f}, '
              f'mape={mape:.4f}%, mase={mase:.4f}, cv_rmse={cv_rmse:.4f}%')

        # 保存结果到文件
        f = open("result_long_term_forecast.txt", 'a')
        f.write(setting + "  \n")
        f.write('r2:{:.4f}, mae:{:.4f}, rmse:{:.4f}, mape:{:.4f}, mase:{:.4f}, cv_rmse:{:.4f}\n\n'
                .format(r2, mae, rmse, mape, mase, cv_rmse))
        f.close()

        return r2, mae, rmse

    def predict(self, setting, load=False):
        pred_data, pred_loader = self._get_data(flag='pred')

        if load:
            path = os.path.join(self.args.checkpoints, setting)
            best_model_path = path + '/' + 'checkpoint.pth'
            self.model.load_state_dict(torch.load(best_model_path))

        preds = []

        self.model.eval()
        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark, batch_cycle) in enumerate(pred_loader):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)
                batch_x_mark = batch_x_mark.float().to(self.device)
                batch_y_mark = batch_y_mark.float().to(self.device)
                batch_cycle = batch_cycle.int().to(self.device)
                # decoder input
                dec_inp = torch.zeros_like(batch_y[:, -self.args.pred_len:, :]).float()
                dec_inp = torch.cat([batch_y[:, :self.args.label_len, :], dec_inp], dim=1).float().to(self.device)
                # encoder - decoder
                if self.args.use_amp:
                    with torch.cuda.amp.autocast():
                        if self.args.output_attention:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark, batch_cycle)[0]
                        else:
                            outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark, batch_cycle)
                else:
                    if self.args.output_attention:
                        outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark, batch_cycle)[0]
                    else:
                        outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark, batch_cycle)
                outputs = outputs.detach().cpu().numpy()
                if pred_data.scale and self.args.inverse:
                    shape = outputs.shape
                    outputs = pred_data.inverse_transform(outputs.squeeze(0)).reshape(shape)
                preds.append(outputs)

        preds = np.array(preds)
        preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])

        # result save
        folder_path = './results/' + setting + '/'
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        np.save(folder_path + 'real_prediction.npy', preds)

        return