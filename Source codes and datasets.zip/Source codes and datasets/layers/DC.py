import torch
import torch.nn as nn
import torch.nn.functional as F


# class DynamicConv1d(nn.Module):
#     """
#     适用于时序预测的一维动态卷积
#     根据输入序列动态生成卷积核
#     """
#
#     def __init__(self, in_channels, out_channels, kernel_size,
#                  num_experts=4, stride=1, padding=0, dilation=1, groups=1, bias=True):
#         super(DynamicConv1d, self).__init__()
#
#         self.in_channels = in_channels
#         self.out_channels = out_channels
#         self.kernel_size = kernel_size
#         self.num_experts = num_experts
#         self.stride = stride
#         self.padding = padding
#         self.dilation = dilation
#         self.groups = groups
#
#         # 专家网络，用于生成不同的卷积核
#         self.weight_generator = nn.Linear(in_channels, num_experts * out_channels * in_channels // groups * kernel_size)
#
#         # 门控网络，决定使用哪个专家的权重
#         self.gate_network = nn.Sequential(
#             nn.AdaptiveAvgPool1d(1),  # 对时序维度进行全局平均池化
#             nn.Flatten(),
#             nn.Linear(in_channels, num_experts),
#             nn.Softmax(dim=-1)
#         )
#
#         if bias:
#             self.bias = nn.Parameter(torch.zeros(out_channels))
#         else:
#             self.register_parameter('bias', None)
#
#     def forward(self, x):
#         batch_size, channels, seq_len = x.shape
#
#         # 通过门控网络获取权重分配
#         gate_weights = self.gate_network(x)  # [batch_size, num_experts]
#
#         # 生成所有专家的卷积核
#         expert_weights = self.weight_generator(
#             x.mean(dim=-1))  # [batch_size, num_experts * out_ch * in_ch * kernel_size]
#         expert_weights = expert_weights.view(batch_size, self.num_experts,
#                                              self.out_channels, self.in_channels // self.groups,
#                                              self.kernel_size)
#
#         # 将输入x按批次处理
#         output_list = []
#         for b in range(batch_size):
#             # 根据门控权重组合专家权重
#             combined_weight = (gate_weights[b].unsqueeze(-1).unsqueeze(-1).unsqueeze(-1) *
#                                expert_weights[b]).sum(dim=0)  # [out_ch, in_ch//groups, kernel_size]
#
#             # 对单个样本执行卷积
#             single_output = F.conv1d(
#                 input=x[b:b + 1],  # [1, in_ch, seq_len]
#                 weight=combined_weight,  # [out_ch, in_ch//groups, kernel_size]
#                 bias=self.bias,
#                 stride=self.stride,
#                 padding=self.padding,
#                 dilation=self.dilation,
#                 groups=self.groups
#             )  # [1, out_ch, new_seq_len]
#
#             output_list.append(single_output)
#
#         output = torch.cat(output_list, dim=0)  # [batch_size, out_ch, new_seq_len]
#
#         return output


class SimplifiedDynamicConv1d(nn.Module):
    """
    简化版的一维动态卷积，适用于时序数据
    """

    def __init__(self, in_channels, out_channels, kernel_size,
                 hidden_dim=64, stride=1, padding=0, dilation=1, groups=1, bias=True):
        super(SimplifiedDynamicConv1d, self).__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.dilation = dilation
        self.groups = groups

        # 用于生成动态卷积核的网络
        self.kernel_generator = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),  # [B, C, 1]
            nn.Flatten(),  # [B, C]
            nn.Linear(in_channels, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, out_channels * in_channels * kernel_size),
            nn.Sigmoid()
        )

        if bias:
            self.bias = nn.Parameter(torch.randn(out_channels))
        else:
            self.register_parameter('bias', None)

    def forward(self, x):
        batch_size, channels, seq_len = x.shape

        # 生成动态卷积核
        dynamic_kernels = self.kernel_generator(x)  # [batch_size, out_ch * in_ch * kernel_size]
        dynamic_kernels = dynamic_kernels.view(batch_size, self.out_channels,
                                               self.in_channels, self.kernel_size)

        # 逐批次应用动态卷积
        outputs = []
        for i in range(batch_size):
            # 单个样本的动态卷积核 [out_ch, in_ch, kernel_size]
            kernel = dynamic_kernels[i]

            # 对单个输入应用动态卷积
            output_i = F.conv1d(
                input=x[i:i + 1],  # [1, in_ch, seq_len]
                weight=kernel,  # [out_ch, in_ch, kernel_size]
                bias=self.bias,
                stride=self.stride,
                padding=self.padding,
                dilation=self.dilation,
                groups=self.groups
            )  # [1, out_ch, new_seq_len]

            outputs.append(output_i)

        return torch.cat(outputs, dim=0)


class TemporalDynamicConvBlock(nn.Module):
    """
    时序动态卷积块，适用于时序预测任务
    """

    def __init__(self, in_channels, out_channels, kernel_size,
                 hidden_dim=64, stride=1, padding=None, dropout_rate=0.1):
        super(TemporalDynamicConvBlock, self).__init__()

        if padding is None:
            padding = kernel_size // 2

        self.dynamic_conv = SimplifiedDynamicConv1d(
            in_channels=in_channels,
            out_channels=out_channels,
            kernel_size=kernel_size,
            hidden_dim=hidden_dim,
            padding=padding,
            stride=stride
        )

        self.norm = nn.BatchNorm1d(out_channels)
        self.activation = nn.GELU()
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        x = self.dynamic_conv(x)
        x = self.norm(x)
        x = self.activation(x)
        x = self.dropout(x)
        return x


# 示例用法和测试
# if __name__ == "__main__":
#     # 创建示例数据 (batch_size, channels, sequence_length)
#     batch_size, channels, seq_len = 8, 16, 100
#     x = torch.randn(batch_size, channels, seq_len)
#
#     # 测试简化版动态卷积
#     conv_layer = SimplifiedDynamicConv1d(
#         in_channels=channels,
#         out_channels=32,
#         kernel_size=3,
#         hidden_dim=64
#     )
#
#     output = conv_layer(x)
#     print(f"Input shape: {x.shape}")
#     print(f"Output shape: {output.shape}")
#
#     # 测试时序动态卷积块
#     block = TemporalDynamicConvBlock(
#         in_channels=channels,
#         out_channels=32,
#         kernel_size=3,
#         hidden_dim=64
#     )
#
#     output_block = block(x)
#     print(f"Block output shape: {output_block.shape}")
#
#     # 计算参数数量
#     total_params = sum(p.numel() for p in conv_layer.parameters())
#     print(f"Total parameters in dynamic conv: {total_params:,}")