import os
import subprocess

def main():
    # 获取当前脚本所在目录
    current_dir = os.path.dirname(os.path.abspath(__file__))
    run_py_path = os.path.join(current_dir, 'run.py')

    experiments = [
        # {
        #     'is_training': 1,
        #     'root_path': './dataset/',
        #     'data_path': 'continuous dataset.csv',
        #     'target': 'nat_demand',
        #     'model_id': 'CONTINU_10_1',
        #     'model': 'EMAformer',
        #     'data': 'continu',
        #     'features': 'MS',
        #     # 按新数据集要求
        #     'seq_len': 3,
        #     'label_len': 3,
        #     'pred_len': 1,
        #     # 15 个外生变量 + nat_demand = 16
        #     'enc_in': 16,
        #     'dec_in': 16,
        #     'c_out': 16,
        #     # 其余使用 ELE 最优超参数
        #     'e_layers': 3,
        #     'des': 'Exp',
        #     'd_model': 512,
        #     'learning_rate': 3e-06,
        #     'd_ff': 512,
        #     'itr': 1,
        #     'cycle': 168,
        #     'kernel_size': 5,
        #     'use_norm': 1,
        # },

        {
            'is_training': 1,
            'root_path': './dataset/',
            'data_path': 'Electricity demand dataset.csv',
            'target': 'total load actual',
            'model_id': 'EDD_1_1',
            'model': 'EMAformer',
            'data': 'EDD',
            'features': 'MS',
            'seq_len': 3,
            'label_len': 3,
            'pred_len': 1,
            'e_layers': 3,
            'enc_in': 9,
            'dec_in': 9,
            'c_out': 9,
            'des': 'Exp',
            'd_model': 128,
            'learning_rate': 5e-06,
            'd_ff': 128,
            'itr': 1,
            'cycle': 1440,
            'kernel_size': 3,
        },


        # 添加其他配置...
    ]

    for exp in experiments:
        cmd = ['python', '-u', str(run_py_path)]
        for key, value in exp.items():
            cmd.append(f'--{key}')
            cmd.append(str(value))

        print(f"运行实验: {exp['model_id']}")
        subprocess.run(cmd, cwd=current_dir)


if __name__ == '__main__':
    main()